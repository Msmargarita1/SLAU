#include "CSR.h"

template<typename T>
CSR<T>::CSR(std::vector<std::vector<T>> a) {
    size = 0;
	for(size_t i = 0; i < a.size(); ++i) {
        for(size_t j = 0; j < a[i].size(); ++j) {
            if (a[i].value != 0) {
                matrix.emplace_back({i, j, a[i][j]})
                ++size;
            }
        }
    }
}

template<typename T>
[[nodiscard]] int CSR<T>::sizeMatrix() {
    return size;
}

template<typename T>
size_t CSR<T>::returnNumb(int num, int tp) {
    if (tp == 0)
        return matrix[num].i;
    if (tp == 1)
        return matrix[num].j;
    if (tp == 2)
        return matrix[num].value;
}